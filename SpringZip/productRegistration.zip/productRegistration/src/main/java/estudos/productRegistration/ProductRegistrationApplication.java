package estudos.productRegistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRegistrationApplication.class, args);
	}

}
