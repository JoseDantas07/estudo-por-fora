package estudos.productRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
