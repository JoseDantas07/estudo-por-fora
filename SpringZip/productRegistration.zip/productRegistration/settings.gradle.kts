rootProject.name = "productRegistration"
