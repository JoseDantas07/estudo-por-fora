package estudos.agregadoInvestimentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgregadoInvestimentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgregadoInvestimentosApplication.class, args);
	}

}
