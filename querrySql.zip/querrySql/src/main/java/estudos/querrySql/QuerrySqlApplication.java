package estudos.querrySql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuerrySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuerrySqlApplication.class, args);
	}

}
