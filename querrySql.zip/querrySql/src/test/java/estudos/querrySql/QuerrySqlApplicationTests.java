package estudos.querrySql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuerrySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
