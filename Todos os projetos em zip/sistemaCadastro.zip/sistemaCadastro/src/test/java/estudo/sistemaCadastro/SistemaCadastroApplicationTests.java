package estudo.sistemaCadastro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCadastroApplicationTests {

	@Test
	void contextLoads() {
	}

}
