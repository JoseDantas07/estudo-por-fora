package estudo.picpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PicpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
