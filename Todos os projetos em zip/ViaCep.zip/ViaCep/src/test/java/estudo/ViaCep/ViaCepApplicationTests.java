package estudo.ViaCep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViaCepApplicationTests {

	@Test
	void contextLoads() {
	}

}
